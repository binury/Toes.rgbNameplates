# RGB Nameplates

Making things a little more colorful, now your name matches your fur!


<img src="https://i.imgur.com/JEMKPgM.png" width="600">

<br/>
<a href='https://ko-fi.com/A0A3YDMVY' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi1.png?v=6' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

## Known Issues
- Nameplate colors are initially delayed, briefly, due to how the game loads in without knowing your own ID
- Undoubtedly there will be mod conflicts probably relating to custom cosmetics


## Roadmap
- Bug fixes
- Custom cosmetic compatibility improvement
- Stylistic enhancements

## [Changelog](https://thunderstore.io/c/webfishing/p/toes/rgbnameplates/changelog)
